namespace Delegate_Day10;

public class Manager:Employee , IComparable<Manager>
{
        public Manager()
        { }
        public Manager(string name, decimal salary):base(name,salary)
        {
        }
        public int CompareTo(Manager? other)
        {
                return this.Salary.CompareTo(other.Salary);
        }
}