﻿using System.Globalization;
using System.Runtime.InteropServices;

namespace Delegate_Day10;
public delegate R Func2<T,R>(T x);
public delegate T Func3<T, Tresult>(T x);


class Program
{
    
    static void Main(string[] args)
    {
        #region q1

        Employee[] emp =
        {
            new("ali", 15000m),
            new("shahd", 20000m),
            new("mohamed", 3000m),
            new("sara", 4000m),
            new("manar", 3000m),

        };
        // SortingAlgorithm.Sort(emp, SortAsc);
        // foreach (var i in emp)
        // {
        //     Console.WriteLine(i.Name+" "+i.Salary);
        // }

        #endregion

        #region Q2

        // int[] res = { 0, 100, 20, 14, 8, 200, 10000 };
        // SortingTwo<int>.Sort(res, SortDesc);
        // foreach (var i in res)
        // {
        //     Console.Write(i + " ");
        // }

        #endregion

        #region Q3

        // string[] arr = { "youseif","ali","alaa" ,"shahd", "ahmed", "mohamed" ,"sama"};
        // SortingTwo<string>.Sort(arr,CompareAsc);
        // foreach (string s in arr)
        // {
        //     Console.Write(s+" ");
        // }

        #endregion

        #region Q4

        // Manager[] arr =
        // {
        //     new Manager("Eman", 500000),
        //     new Manager("Malak", 100000),
        //     new Manager("Hour", 400000),
        //
        // };
        // SortingAlgorithm.Sort(arr,SortAsc);
        // foreach (Manager m in arr)
        // {
        //     Console.WriteLine($"Manager_Name: {m.Name} ,  Salary: {m.Salary} ");
        // }

        #endregion

        #region Q5

        // SortingAlgorithm.Sort<Employee>(emp,SortEmpAsc);
        // foreach (var i in emp)
        // {
        //     Console.Write(i.Name+"\n");
        // }

        #endregion

        #region Q6
        // int[] array = { 100, 70, 21, 4, 8, 9 };
        // Func<int[], int[]> CompareFunc = delegate(int[] array)
        // {
        //
        //     Array.Sort(array);
        //     return array;
        // };
        // int [] res=CompareFunc(array);
        // foreach (var i in  res)
        // {
        //     Console.Write(i+" ");
        // }
        //
        // Console.WriteLine("\n================ lambda ===========");
        // #endregion
        // #region Q6 lambda
        //
        // Func<int[], int[]> CompareFunc2 = (array) => // multiple line{}
        // {
        //     Array.Sort(array);
        //     return array;
        // };
        // int []res2 = CompareFunc2(array);
        // Console.Write(string.Join(" ", res2));
        #endregion
        #region Q7
        //
        // int[] arr = { 100, 2, 1, 9, 8 };
        // SortingAlgorithm.Swap(ref arr[0], ref arr[1]);
        // Console.WriteLine(arr[0]+" "+arr[1]);
        #endregion
        #region Q8
        // SortingAlgorithm.Sort(emp,CompareEmpAsc);
        // foreach (var i in emp)
        // {
        //     Console.WriteLine(i.Salary + " " + i.Name);
        // }
        #endregion
        #region Q9
        // Console.WriteLine(GetDefault<Employee>());
        // Console.WriteLine(GetDefault<int>());
        #endregion
        #region Q10
        // Employee[] cloneemp = emp
        //     .Select(x => (Employee)x.Clone())
        //     .ToArray();
        // SortingAlgorithm<Employee>.Sort(
        //     cloneemp,
        //     (x, y) => x.Salary > y.Salary
        // );
        // Console.WriteLine("first array version  :");
        // Console.WriteLine(string.Join("\n", emp.Select(x => $"{x.Name} ,  {x.Salary}")));
        // Console.WriteLine("\nCloned array version after Sort:");
        // Console.WriteLine(string.Join("\n", cloneemp.Select(x => $"{x.Name} , {x.Salary}")));
        #endregion
        #region Q11
        // List<string> names = new List<string>
        // {
        //     "Shahd",
        //     "Ayman",
        //     "Mohamed"
        // };
        // Func<string, string> f1 = Test;
        // List<string> result = TransformList(names, f1);
        // Console.WriteLine(string.Join(" ", result));

        #endregion
        #region Q12
        // Func<int, int, int> f1 = (x, y) => x * y;
        // Func<int, int, int> f2= (x, y) => x + y;
        // Func<int, int, int> f3= (x, y) => x - y;
        // Func<int, int, int> f4= (x, y) => x / y;
        // Console.WriteLine(f1(10,2));
        // Console.WriteLine(f2(10,2));
        // Console.WriteLine(f3(10,2));
        // Console.WriteLine(f4(10,2)); 
        //if make one ref execute all operation by make +=
        // Will return last operation value only
        #endregion
        #region Q13
        // List<int> numbers = new List<int>
        // {
        //     10, 20, 30, 40
        // };
        // Func2<int, string> f1 = x => x.ToString();
        // List<string> result = TransformList(numbers, f1);
        // Console.WriteLine(string.Join(" ", result));
        #endregion
        #region Q14
        // Func3<int,int>f3=x=>x*x;
        // Console.WriteLine(f3(10));
        #endregion
        #region Q15
        // List<string> names = new List<string>
        // {
        //     "Shahd",
        //     "Ayman",
        //     "Mohamed"
        // };
        // Action<string> a1 = x => Console.Write(x+" ");
        // PrintList(names, a1);
        #endregion
        #region Q16
        // List<int> l1 = [10, 2, 4, 5, 6, 0, 3, 1];
        // List<int> l2 = [];
        // Predicate<int> p1=(x)=> x % 2 == 0;
        // l2=Checkenven(l1,p1);
        // Console.WriteLine(string.Join(" ",l2));
        #endregion
        #region Q17
        // Func<string, bool> f1 = delegate(string s)
        // {
        //     return s.Contains('s');
        //
        // };
        // List<string> names = new List<string>
        // {
        //     "shahd",
        //     "sara",
        //     "ali",
        //     "mohamed"
        // };
        // List<string> result = FilterList(names, f1);
        // Console.WriteLine(string.Join(" ", result));
        #endregion
        #region Q18
        // Action<int, int> f = delegate(int x, int y)
        // {
        //     Console.WriteLine(x + y);
        //     Console.WriteLine(x - y);
        //     Console.WriteLine(x * y);
        //
        // };
        // f(10, 5);

        #endregion
        #region Q19
        // Predicate<string> predicate=(x)=>x.Length>3||x.Contains('e');
        // Console.WriteLine(predicate("shahd"));
        #endregion
        #region Q20
        // Func<double, double,double> action = (x, y)=>
        //     Math.Pow(x,y);
        // Func<double, double, double> action2 = (x, y) =>
        //     x / y;
        // Console.WriteLine(action(10,2));
        // Console.WriteLine(action2(100,10));
        #endregion

    }


    public static bool SortAsc(Manager x, Manager y)
    {
        return x.Salary > y.Salary;

    }

    public static bool SortEmpAsc(Employee x, Employee y)
    {
        return x.Name.Length > y.Name.Length;

    }

    public static bool SortDesc(int x, int y) => x < y;

    public static bool CompareAsc(string x, string y)
    {
        return x.Length > y.Length;
    }

    public static bool CompareEmpAsc(Employee x, Employee y)
    {
        if (x.Salary != y.Salary)
        {
            return x.Salary > y.Salary;
        }
        return  string.Compare(x.Name, y.Name, StringComparison.OrdinalIgnoreCase) > 0;
    }
    public static T GetDefault<T>() //t ref->null , value type return default value
    {
        return default(T);
    }
    public static string Test(string s)
    {
        return s.ToUpper();
    }
    public static List<string> TransformList(
        List<string> list,Func<string,string> f)
    {
        List<string> result = new List<string>();
        foreach (var i in list)
        {
            result.Add(f(i));
        }
        return result;
    }
    public static List<R> TransformList<T, R>(
        List<T> list,
        Func2<T, R> func)
    {
        List<R> result = new List<R>();
        foreach (var item in list)
        {
            result.Add(func(item));
        }
        return result;
    }
    public static void PrintList(List<string> list, Action<string> a)
    {
        foreach (var item in list)
        {
            a.Invoke(item);
        }
    }
    public static List<T> Checkenven<T>(List<T> l1, Predicate<T> p)
    {
        List<T> res=new List<T>();
        foreach (var i in l1)
        {
            if (p.Invoke(i))
            {
                res.Add(i);
            } ;
        }
        return res;
    }
    public static List<string> FilterList(
        List<string> list,
        Func<string, bool> condition)
    {
        List<string> result = new List<string>();

        foreach (var i in list)
        {
            if (condition(i))
            {
                result.Add(i);
            }
        }
        return result;
    }

}

    