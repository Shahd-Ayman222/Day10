namespace Delegate_Day10;
public delegate bool FuncDelegate1<T>(T x,T y);
public class SortingAlgorithm <T> where T:ICloneable
{
    public static void  Sort<T>(T[] arr, FuncDelegate1<T> func) // the pros to make delegate with T to reuse it in many questions
    {
        for (int i = 0; i < arr.Length-1; i++)
        {
            for (int j = 0;j<arr.Length-1-i; j++)
            {
                if (func.Invoke(arr[j], arr[j + 1]))
                {
                    Swap(ref arr[j], ref arr[j + 1]);
                }
                
            }
        }
        
    }
    public static void Swap<T>(ref T a, ref T b)
    {
        T temp = a;
        a = b;
        b = temp;
    }
 
}