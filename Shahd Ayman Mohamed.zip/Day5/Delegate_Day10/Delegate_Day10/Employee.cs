namespace Delegate_Day10;

public class Employee : ICloneable
{
    public Employee()
    {
    }

    public string Name { get; set; } 
    public decimal Salary { get; set; }
    public Employee(string name, decimal salary)
    {
        Name = name;
        Salary = salary;
    }

    public object Clone()
    {
        return new Employee(Name, Salary);
    }
    
}