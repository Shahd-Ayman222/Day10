using System.Numerics;

namespace Delegate_Day10;

public delegate bool FuncDelegate2<T>(T x, T y);

public class SortingTwo<T> 
{
    
    public static void Sort(T[] array, FuncDelegate2<T> f2) 
    {
        for (int i = 0; i < array.Length - 1; i++)
        {
            for (int j = 0; j < array.Length - 1 - i; j++)
            {
                if (f2.Invoke(array[j], array[j + 1]))
                {
                    Swap(ref array[j], ref array[j + 1]);
                }
            }
        }
    }

    public static void Swap<T>(ref T a, ref T b) 
    {
        T temp = a;
        a = b;
        b = temp;
    }
}