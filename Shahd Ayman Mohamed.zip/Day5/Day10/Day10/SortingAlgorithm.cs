namespace Day10;

public class SortingAlgorithm<T>
{
    public static void Sort(T[] arr, Comparison<T> comparison)
    {
        for (int i = 0; i < arr.Length - 1; i++)
        {
            for (int j = 0; j < arr.Length - i - 1; j++)
            {
                if (comparison(arr[j], arr[j + 1]) > 0)
                {
                    T temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }
    public static void Sort2(T[] arr, Comparison<T> comparison)
    {
            Array.Sort(arr, comparison);
    }
    public static void Sort3(T[] arr, Func<T, T, bool> f)
    {
        for (int i = 0; i < arr.Length - 1; i++)
        {
            for (int j = 0; j < arr.Length - i - 1; j++)
            {
                if (!f(arr[j], arr[j + 1]))
                {
                    T temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
        
    }

    
    
}