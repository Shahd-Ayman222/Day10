namespace Day10;
public class Manager:Empolyee,IComparable<Manager>
{
    public Manager(string name, decimal salary) : base(name, salary)
    { }
    public int CompareTo(Manager? other)
    {
        if (other == null)
            return 1;
        return Salary.CompareTo(other.Salary);
    }
}