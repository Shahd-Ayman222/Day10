namespace Day10;

public class Empolyee
{
    public string Name { get; set; }
    public decimal Salary { get; set; }
    public Empolyee(string name, decimal salary)
    {
        Name = name;
        Salary = salary;
    }
    public override string ToString()
    {
        return $"{Name} - {Salary}";
    }
}
    