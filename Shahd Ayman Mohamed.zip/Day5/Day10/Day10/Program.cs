﻿namespace Day10;

class Program
{
    static void Main(string[] args)
    {
        #region
        Empolyee[] e =
          {
            new Empolyee("Shahd", 15000),
            new Empolyee("Mohamed", 10000),
            new Empolyee("Youseif", 12000),
            new Empolyee("Ali", 5000)
           };
        SortingAlgorithm<Empolyee>.Sort(
            e,
            (e1, e2) => e1.Salary.CompareTo(e2.Salary)
        );
        foreach (Empolyee i in e)
        {
            Console.WriteLine(i);
        }
        #endregion
        #region
        // int[] arr = {10, 22, 80, 1,99};
        // SortingAlgorithm<int>.Sort2(arr, (x, y) => y.CompareTo(x));
        // foreach (var i in arr)
        // {
        //     Console.Write(i+" ");
        // }
        #endregion
        #region
        // string[] arr = { "Shahd", "Ali", "Mohamed", "Ahmed" };
        // SortingAlgorithm<string>.Sort2(arr, (x, y) => x.Length.CompareTo(y.Length));
        // foreach (string i in arr)
        // {
        //     Console.WriteLine(i);
        // }
        #endregion
        #region
        // Manager[] managers = {
        //     new Manager("Shahd", 15000),
        //     new Manager("Ali", 10000),
        //     new Manager("Ahmed", 20000)
        // };
        // Array.Sort(managers);
        // foreach (Manager manager in managers)
        // {
        //     Console.WriteLine($"{manager.Name} , {manager.Salary}");
        // }
        #endregion
        #region
        // Func<Empolyee, Empolyee, bool> f =
        //     (x, y) => x.Name.Length < y.Name.Length;
        // SortingAlgorithm<Empolyee>.Sort3(e, f);
        #endregion
       
    }
}